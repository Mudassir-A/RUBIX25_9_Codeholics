Download and save these icons:
- zero-waste.png (recycling symbol)
- refill.png (water drop symbol)
- ethical.png (store/marketplace symbol)

You can use free icons from:
https://www.flaticon.com/ or create your own 